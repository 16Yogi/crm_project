from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count, Prefetch
import json

# Assuming your models are in 'apps.models'
from apps.models import User, Team 


@login_required
def user_management(request):
    user = request.user

    # --- Access control ---
    if not user.is_superuser and user.role not in ['admin', 'supervisor']:
        return HttpResponseForbidden("You do not have permission to access this page.")

    # === POST Handling ===
    if request.method == 'POST':
        form_type = request.POST.get('form_type')

        # --- Handle Add User ---
        if form_type == 'add_user':
            full_name = request.POST.get('full_name')
            email = request.POST.get('email')
            role = request.POST.get('role')
            password = request.POST.get('password')
            team_id = request.POST.get('team')
            reports_to_id = request.POST.get('reports_to')

            if not all([full_name, email, role, password]):
                messages.error(request, "Please fill all required fields.")
                return redirect('user_management')

            if User.objects.filter(email=email).exists():
                messages.error(request, f"A user with email '{email}' already exists.")
                return redirect('user_management')

            # Supervisor cannot create supervisors/admins
            if user.role == 'supervisor' and role != 'agent':
                messages.error(request, "You can only create agent users.")
                return redirect('user_management')

            # Supervisor can only assign their own team
            if user.role == 'supervisor':
                team_id = user.team.id if user.team else None
                reports_to_id = user.id

            try:
                name_parts = full_name.split(' ', 1)
                new_user = User.objects.create_user(
                    username=email,
                    email=email,
                    password=password,
                    first_name=name_parts[0],
                    last_name=name_parts[1] if len(name_parts) > 1 else '',
                    role=role
                )

                # Assign team
                if team_id:
                    new_user.team = get_object_or_404(Team, pk=team_id)

                # Assign supervisor
                if role == 'agent':
                    if reports_to_id:
                        new_user.reports_to = get_object_or_404(User, pk=reports_to_id, role='supervisor')

                if role == 'supervisor' and user.role == 'admin':
                    team = get_object_or_404(Team, pk=team_id)
                    team.supervisor = new_user
                    team.save()

                new_user.save()
                messages.success(request, f"User '{full_name}' created successfully!")
            except Exception as e:
                messages.error(request, f"Error creating user: {e}")

            return redirect('user_management')

        # --- Handle Add Team (Admins only) ---
        elif form_type == 'add_team':
            if user.role != 'admin' and not user.is_superuser:
                return HttpResponseForbidden("Only admins can create teams.")

            team_name = request.POST.get('name')
            supervisor_id = request.POST.get('supervisor')

            if not team_name:
                messages.error(request, "Team name is required.")
                return redirect('user_management')

            if Team.objects.filter(name=team_name).exists():
                messages.error(request, f"A team named '{team_name}' already exists.")
                return redirect('user_management')

            try:
                team = Team.objects.create(name=team_name)
                if supervisor_id:
                    supervisor = get_object_or_404(User, pk=supervisor_id, role='supervisor')
                    team.supervisor = supervisor
                    team.save()
                    supervisor.team = team
                    supervisor.save(update_fields=['team'])

                messages.success(request, f"Team '{team_name}' created successfully.")
            except Exception as e:
                messages.error(request, f"Error creating team: {e}")

            return redirect('user_management')
        elif form_type == 'update_team':
            team_id = request.POST.get('team_id')
            team_name = request.POST.get('team_name')   
            supervisor_id = request.POST.get('supervisor')

            try:
                team = get_object_or_404(Team, pk=team_id)
                if team_name:
                    team.name = team_name
                if supervisor_id:
                    supervisor = get_object_or_404(User, pk=supervisor_id, role='supervisor')
                    team.supervisor = supervisor
                    supervisor.team = team
                    supervisor.save(update_fields=['team'])
                else:
                    team.supervisor = None

                team.save()
                messages.success(request, f"Team '{team.name}' updated successfully.")
            except Exception as e:
                messages.error(request, f"Error updating team: {e}")

    # === GET Context ===
    if user.role == 'admin' or user.is_superuser:
        all_users = User.objects.select_related('team', 'reports_to').order_by('first_name', 'last_name')
        all_teams = Team.objects.select_related('supervisor').annotate(member_count=Count('members')).all()
        supervisors = User.objects.filter(role='supervisor')
    elif user.role == 'supervisor':
        # Supervisor only sees agents in their team
        all_users = User.objects.filter(team=user.team, role='agent').select_related('team', 'reports_to')
        all_teams = Team.objects.filter(pk=user.team_id).select_related('supervisor').annotate(member_count=Count('members'))
        supervisors = User.objects.filter(pk=user.id)  # only themselves

    teams_with_supervisors_json = {
        team.id: [{'id': team.supervisor.id, 'name': team.supervisor.get_full_name()}]
        for team in all_teams if team.supervisor
    }

    context = {
        'users': all_users,
        'teams': all_teams,
        'supervisors': supervisors,
        'teams_with_supervisors_json': json.dumps(teams_with_supervisors_json),
    }
    return render(request, 'component/UserManagement.html', context)


@login_required
def deactivate_user(request, user_id):
    if not request.user.is_superuser and request.user.role != 'admin':
        return HttpResponseForbidden()
    user_to_deactivate = get_object_or_404(User, pk=user_id)
    if user_to_deactivate == request.user:
        messages.error(request, "You cannot deactivate your own account.")
        return redirect('user_management')
    user_to_deactivate.is_active = False
    user_to_deactivate.save()
    messages.success(request, f"User '{user_to_deactivate.get_full_name()}' has been deactivated.")
    return redirect('user_management')

@login_required
def activate_user(request, user_id):
    if not request.user.is_superuser and request.user.role != 'admin':
        return HttpResponseForbidden()
    user_to_activate = get_object_or_404(User, pk=user_id)
    user_to_activate.is_active = True
    user_to_activate.save()
    messages.success(request, f"User '{user_to_activate.get_full_name()}' has been activated.")
    return redirect('user_management')

@login_required
def delete_user(request, user_id):
    if not request.user.is_superuser and request.user.role != 'admin':
        return HttpResponseForbidden()
    user_to_delete = get_object_or_404(User, pk=user_id)
    if user_to_delete.id == request.user.id:
        messages.error(request, "You cannot delete your own account.")
        return redirect('user_management')
    if request.method == 'POST':
        user_name = user_to_delete.get_full_name()
        user_to_delete.delete()
        messages.success(request, f"User '{user_name}' has been permanently deleted.")
    return redirect('user_management')