from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Sum, Q
from django.utils import timezone
from datetime import timedelta, date
from apps.models import Client, Deal, Task, User


@login_required
def admin(request):
    user = request.user

    today = timezone.now().date()
    this_week_start = today - timedelta(days=today.weekday())
    this_month_start = today.replace(day=1)
    this_year_start = today.replace(month=1, day=1)

    start_date_str = request.GET.get("start_date")
    end_date_str = request.GET.get("end_date")

    active_filter = None

    if start_date_str and end_date_str:
        try:
            start_date = date.fromisoformat(start_date_str)
            end_date = date.fromisoformat(end_date_str)

            if start_date == today and end_date == today:
                active_filter = "today"
            elif start_date == this_week_start and end_date == today:
                active_filter = "this_week"
            elif start_date == this_month_start and end_date == today:
                active_filter = "this_month"
            elif start_date == this_year_start and end_date == today:
                active_filter = "this_year"

            list_title = f"Leads from {start_date.strftime('%b %d, %Y')} to {end_date.strftime('%b %d, %Y')}"
        except ValueError:
            start_date = this_month_start
            end_date = today
            list_title = "This Month's New Leads"
            active_filter = "this_month"
    else:
        start_date = this_month_start
        end_date = today
        list_title = "This Month's New Leads"
        active_filter = "this_month"

    # ======================
    # Filtered Leads Query
    # ======================
    leads_base_query = Client.objects.filter(created_at__date__range=[start_date, end_date])

    # -----------------------
    # Different for Admin and Supervisor
    # -----------------------
    if user.role == "admin":
        # Admin sees everything
        filtered_leads_query = leads_base_query
        new_leads_count = filtered_leads_query.count()

        # Period revenue: All deals
        period_revenue = Deal.objects.filter(
            stage="won",
            closed_at__date__range=[start_date, end_date]
        ).aggregate(total_revenue=Sum("value"))["total_revenue"] or 0

        pending_tasks_count = Task.objects.filter(is_completed=False).count()
        unassigned_leads_count = Client.objects.filter(assigned_to__isnull=True).count()

    elif user.role == "supervisor":
        # Supervisor: restrict to leads assigned to users in supervisor's team
        team_users = User.objects.filter(team=user.team)

        filtered_leads_query = leads_base_query.filter(assigned_to__in=team_users)
        new_leads_count = filtered_leads_query.count()

        period_revenue = Deal.objects.filter(
            stage="won",
            closed_at__date__range=[start_date, end_date],
            assigned_to__in=team_users
        ).aggregate(total_revenue=Sum("value"))["total_revenue"] or 0

        pending_tasks_count = Task.objects.filter(
            is_completed=False,
            assigned_to__in=team_users
        ).count()

        unassigned_leads_count = Client.objects.filter(
            assigned_to__isnull=True
        ).count()  # या supervisor के हिसाब से filter करो अगर चाहो

    else:
        # अगर कोई और role है तो—for safety—empty data
        filtered_leads_query = Client.objects.none()
        new_leads_count = 0
        period_revenue = 0
        pending_tasks_count = 0
        unassigned_leads_count = 0

    filtered_leads_list = filtered_leads_query.order_by("-created_at")

    context = {
        "new_leads_count": new_leads_count,
        "period_revenue": period_revenue,
        "pending_tasks_count": pending_tasks_count,
        "unassigned_leads_count": unassigned_leads_count,

        "filtered_leads": filtered_leads_list,
        "leads_list_title": list_title,
        "total_filtered_leads": new_leads_count,

        "start_date_str": start_date.isoformat(),
        "end_date_str": end_date.isoformat(),

        "today_iso": today.isoformat(),
        "this_week_start_iso": this_week_start.isoformat(),
        "this_month_start_iso": this_month_start.isoformat(),
        "this_year_start_iso": this_year_start.isoformat(),
        "active_filter": active_filter,
    }

    return render(request, "component/Dashboard_admin.html", context)
