# In your app's views.py

import json
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, F
from django.utils import timezone
from datetime import timedelta
# Make sure to import all the necessary models from your app
from apps.models import Client, User, Team

@login_required
def lead_management(request):
    """
    Handles the display and management of leads.
    - Role-based access: Admin sees all, Supervisor sees their team's leads.
    - Supports filtering by search, source, status, and date.
    - Handles two POST actions:
        1. 'assign_lead': Assigns an existing lead from the table.
        2. 'add_lead': Creates a new lead from the modal, with an option
                       to assign it immediately.
    """
    user = request.user
    today = timezone.now().date()

    # =================================================================
    # 1. PERMISSIONS & INITIAL QUERYSETS
    # =================================================================
    if user.role == 'admin':
        leads_query = Client.objects.all()
        assignable_agents = User.objects.filter(role__in=['agent', 'supervisor'], is_active=True).select_related('team')
        teams_for_modal = Team.objects.all().order_by('name')
    
    elif user.role == 'supervisor':
        agents_in_team = User.objects.filter(team=user.team, role='agent')
        leads_query = Client.objects.filter(
            Q(assigned_to__isnull=True) | Q(assigned_to__in=agents_in_team) | Q(assigned_to=user)
        )
        assignable_agents = agents_in_team
        teams_for_modal = Team.objects.filter(id=user.team.id)

    else:
        messages.error(request, "You do not have permission to view this page.")
        return redirect('dashboard')

    leads_query = leads_query.exclude(status__in=['customer', 'lost'])

    # =================================================================
    # 2. HANDLE POST REQUESTS (FORM SUBMISSIONS)
    # =================================================================
    if request.method == 'POST':
        action = request.POST.get('action')

        if action == 'assign_lead':

            lead_id = request.POST.get('lead_id')
            agent_id = request.POST.get('agent_id')
            if not lead_id or not agent_id:
                messages.error(request, "Invalid submission. Please select a lead and an agent.")
            else:
                try:
                    lead_to_assign = Client.objects.get(id=lead_id)
                    agent = User.objects.get(id=agent_id)
                    if user.role == 'supervisor' and agent.team != user.team:
                        messages.error(request, "You can only assign leads to agents in your own team.")
                    else:
                        lead_to_assign.assigned_to = agent
                        if lead_to_assign.status == 'new': lead_to_assign.status = 'contacted'
                        lead_to_assign.save()
                        messages.success(request, f"Lead '{lead_to_assign.full_name}' assigned to {agent.get_full_name()}.")
                except (Client.DoesNotExist, User.DoesNotExist):
                    messages.error(request, "An error occurred. The selected lead or agent does not exist.")


        elif action == 'add_lead':
            full_name = request.POST.get('full_name')
            email = request.POST.get('email')
            phone_number_from_form = request.POST.get('phone') 
            source = request.POST.get('source')
            agent_id = request.POST.get('agent_id')

            if not all([full_name, email, phone_number_from_form, source]):
                messages.error(request, "Please fill out all required lead detail fields.")
            else:
                try:
                    new_lead = Client(
                        full_name=full_name,
                        email=email,
                        phone_number=phone_number_from_form, 
                        source=source,
                        status='new' 
                    )
                    
                    if agent_id:
                        agent_to_assign = User.objects.get(id=agent_id)
                        new_lead.assigned_to = agent_to_assign
                        new_lead.status = 'contacted'
                        new_lead.save()
                        messages.success(request, f"New lead '{new_lead.full_name}' created and assigned to {agent_to_assign.get_full_name()}.")
                    else:
                        new_lead.save()
                        messages.success(request, f"New unassigned lead '{new_lead.full_name}' has been created.")

                except User.DoesNotExist:
                    messages.error(request, "The selected agent does not exist. The lead was created but remains unassigned.")
                except Exception as e:
                    # This will help debug any other potential issues
                    messages.error(request, f"An unexpected error occurred while creating the lead: {e}")

        return redirect(request.get_full_path())

    # =================================================================
    # 3. APPLY GET FILTERS & 4. PREPARE CONTEXT (These parts are correct)
    # =================================================================
    search_query = request.GET.get('q', '')
    if search_query:
        leads_query = leads_query.filter(Q(full_name__icontains=search_query) | Q(email__icontains=search_query))

    teams_with_agents_map = {}
    all_agents_for_dropdown = User.objects.filter(role='agent', is_active=True, team__isnull=False)
    for agent in all_agents_for_dropdown:
        if agent.team.id not in teams_with_agents_map:
            teams_with_agents_map[agent.team.id] = []
        teams_with_agents_map[agent.team.id].append({'id': agent.id, 'name': agent.get_full_name()})
    teams_with_agents_json = json.dumps(teams_with_agents_map)

    leads = leads_query.select_related(
        'assigned_to', 'assigned_to__team', 'assigned_to__team__supervisor'
    ).order_by(F('assigned_to_id').asc(nulls_first=True), '-created_at')

    context = {
        'leads': leads,
        'assignable_agents': assignable_agents,
        'source_choices': Client.SOURCE_CHOICES,
        'teams': teams_for_modal,
        'teams_with_agents_json': teams_with_agents_json,
        'search_query': search_query,
    }

    return render(request, 'component/LeadManagement.html', context)