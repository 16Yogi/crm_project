from django.db.models import Sum, Count, Avg
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from apps.models import Team, Deal, User
from django.db.models import Q


@login_required
def team_performance(request):
    user = request.user

    # Start with empty queryset placeholders
    teams = Team.objects.none()
    agents = User.objects.none()

    # For performance metrics
    deals = Deal.objects.none()

    if user.role == 'admin':
        # Admin sees all teams and all agents
        teams = Team.objects.all()
        agents = User.objects.filter(role='agent')
        deals = Deal.objects.filter(stage='won')
    elif user.role == 'supervisor':
        # Supervisor sees only their supervised teams and their agents
        teams = Team.objects.filter(supervisor=user)
        agents = User.objects.filter(team__in=teams, role='agent')
        deals = Deal.objects.filter(stage='won', assigned_to__in=agents)
    else:
        # Agent sees only own performance
        teams = Team.objects.filter(
            id=user.team_id) if user.team else Team.objects.none()
        agents = User.objects.filter(id=user.id)
        deals = Deal.objects.filter(stage='won', assigned_to=user)

    # Aggregate stats
    total_revenue = deals.aggregate(total=Sum('value'))['total'] or 0
    total_deals = deals.count()
    avg_deal_size = deals.aggregate(avg=Avg('value'))['avg'] or 0

    total_assigned_deals = Deal.objects.filter(
    assigned_to__in=agents if user.role != 'agent' else [user]
).count()
    
    win_rate = (
    (total_deals / total_assigned_deals) * 100
    if total_deals > 0 and total_assigned_deals > 0 else 0
)

    # Team summary matrix
    team_performance = []
    for team in teams:
        team_deals = deals.filter(assigned_to__team=team)
        team_total = team_deals.aggregate(total=Sum('value'))['total'] or 0
        team_count = team_deals.count()
        team_avg = team_deals.aggregate(avg=Avg('value'))['avg'] or 0

        team_performance.append({
            'team': team,
            'deals_won': team_count,
            'revenue': team_total,
            'avg_deal_size': team_avg,
        })

    # Agent leaderboar
    agent_performance = (agents.annotate(deals_won=Count('deals', filter=Q(deals__stage='won')),revenue=Sum('deals__value', filter=Q(deals__stage='won'))).order_by('-revenue'))

    context = {
        'user': user,
        'title': 'Team Performance',
        'active_tab': 'team_performance',
        'total_revenue': total_revenue,
        'total_deals': total_deals,
        'avg_deal_size': avg_deal_size,
        'win_rate': round(win_rate, 2),
        'team_performance': team_performance,
        'agent_performance': agent_performance,
    }
    return render(request, 'component/Team_perfomance.html', context)
