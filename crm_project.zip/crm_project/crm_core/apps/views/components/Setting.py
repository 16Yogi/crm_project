# your_app/views.py

from django.shortcuts import render,redirect
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
import json
from django.contrib import messages

from apps.models import *



@login_required
def Setting(request):
    if request.method == 'POST' and request.user.role == 'admin':
        setting = WebsiteSetting.load()
        setting.website_name = request.POST.get('website_name', setting.website_name)
        setting.save()
        messages.success(request, 'Website name updated successfully!')
        return redirect('settings') # Redirect back to the settings page

    # --- Existing logic for routing rules ---
    rules = RoutingRule.objects.select_related('target_team').all()
    teams = Team.objects.all()

    condition_fields = [
        {'value': 'campaign_name', 'display': 'Campaign Name'},
        {'value': 'source', 'display': 'Lead Source'},
        {'value': 'country', 'display': 'Country'},
    ]
    
    # --- GET WEBSITE SETTING TO DISPLAY ---
    website_setting = WebsiteSetting.load()
    
    context = {
        'rules': rules,
        'teams': teams,
        'condition_fields': condition_fields,
        'website_setting': website_setting, # Pass the setting to the template
    }
    
    return render(request, 'component/Setting.html', context)


@login_required
@csrf_exempt 
@require_POST
def rule_create_or_update_api(request):
    try:
        data = json.loads(request.body)
        rule_id = data.get('rule_id')
        
        defaults = {
            'name': data.get('rule_name'),
            'priority': data.get('priority'),
            'condition_field': data.get('condition_field'),
            'condition_operator': data.get('condition_operator'),
            'condition_value': data.get('condition_value'),
            'target_team_id': data.get('target_team'),
        }

        if rule_id:
            rule, created = RoutingRule.objects.update_or_create(
                id=rule_id, defaults=defaults
            )
            message = "Rule updated successfully."
        else:
            rule = RoutingRule.objects.create(**defaults)
            message = "Rule created successfully."

        return JsonResponse({'status': 'success', 'message': message, 'rule_id': rule.id})

    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=400)


@login_required
@csrf_exempt
@require_POST
def rule_delete_api(request):

    try:
        data = json.loads(request.body)
        rule_id = data.get('rule_id')
        
        rule = RoutingRule.objects.get(id=rule_id)
        rule.delete()
        
        return JsonResponse({'status': 'success', 'message': 'Rule deleted successfully.'})

    except RoutingRule.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Rule not found.'}, status=404)
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=400)