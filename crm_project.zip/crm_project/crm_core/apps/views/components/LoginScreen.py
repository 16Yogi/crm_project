# your_app_name/views.py

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from apps.models import User 

def LoginScreen(request):
    if request.method == 'POST':
        print("--- CHECK 1: FORM DATA RECEIVED ---")
        print(request.POST)
        print("---------------------------------")
        
        role_from_form = request.POST.get('role')
        email_or_username = request.POST.get('email', '').strip()
        password = request.POST.get('password')

        print(f"--- CHECK 1: ROLE FROM FORM ---",role_from_form)

        try:
            user_obj = User.objects.get(email=email_or_username)
            username = user_obj.username
        except User.DoesNotExist:
            username = email_or_username
        
        user = authenticate(request, username=username, password=password)


        print(f"--- CHECK 2: AUTHENTICATION RESULT ---")
        print(f"User Object: {user}")
        print("--------------------------------------")

        if user is not None:
            print(f"--- CHECK 3: ROLE COMPARISON ---")
            print(f"Role from Database (user.role): '{user.role}'")
            print(f"Role from Form (role_from_form): '{role_from_form}'")
            print(f"Is Superuser: {user.is_superuser}")
            print("--------------------------------")

            if user.is_superuser and role_from_form == 'admin':
                login(request, user)
                print("SUCCESS: Superuser logged in as admin.")
                return redirect('admin_dashboard') 
            
            if user.role == role_from_form:
                login(request, user)
                print(f"SUCCESS: User logged in with role '{user.role}'.")
                # Redirect logic
                if user.role == 'supervisor':
                    return redirect('admin_dashboard')
                elif user.role == 'agent':
                    return redirect('admin_dashboard/')
                elif user.role == 'admin':
                    return redirect('admin_dashboard')
            
            # If nothing matches, it's a role mismatch error
            error_message = "wrong role selected"
            print(f"ERROR: {error_message}")
            return render(request, 'component/Login.html', {'error': error_message})
        else:
            error_message = "Invalid username or password."
            print(f"ERROR: {error_message}")
            return render(request, 'component/Login.html', {'error': error_message})

    return render(request, 'component/Login.html')