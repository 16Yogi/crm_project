import json
import requests
from django.utils import timezone
from datetime import timedelta
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, get_object_or_404, redirect
from django.views.decorators.http import require_POST, require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Count, Q
from apps.models import Client, Team, User, RoutingRule, Workflow, Step, Task

# ==============================================================================
# HELPER & WEBHOOK FUNCTIONS (Unchanged - collapsed for brevity)
# ==============================================================================


def get_lead_from_graph_api(leadgen_id):
    ACCESS_TOKEN = "YOUR_PAGE_ACCESS_TOKEN_HERE"
    url = f"https://graph.facebook.com/v19.0/{leadgen_id}?fields=field_data&access_token={ACCESS_TOKEN}"
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        lead_details = {field.get('name', '').lower().replace(' ', '_'): ', '.join(
            field.get('values', [])) for field in data.get('field_data', [])}
        return lead_details
    except requests.exceptions.RequestException as e:
        return None


def detect_platform(data, request):
    print(f"Detecting platform from data: {data}")  # Debugging line
    if 'user_column_data' in data:
        return 'google_ads'
    if 'entry' in data and 'leadgen_id' in str(data):
        return 'facebook_ads'
    if 'website' in data:
        return 'website_form'
    
    return 'unknown_platform'


def extract_lead_data(webhook_data, source):
    if source == 'google_ads':
        data = {f.get('column_name', '').lower().replace(' ', '_'): f.get(
            'string_value') for f in webhook_data.get('user_column_data', [])}
        data['campaign_name'] = webhook_data.get(
            'campaign_name', 'Unknown Google Campaign')
        return data
    elif source == 'facebook_ads':
        try:
            value = webhook_data['entry'][0]['changes'][0]['value']
            leadgen_id = value['leadgen_id']
            data = get_lead_from_graph_api(leadgen_id)
            if data:
                data['campaign_name'] = value.get(
                    'campaign_name', 'Unknown Facebook Campaign')
            return data
        except (IndexError, KeyError):
            return None

    return webhook_data


def route_and_assign_lead(lead, lead_data_dict):
    # This logic now sits alongside the more powerful workflow automation
    trigger_workflows(lead)  # Trigger workflow first

    # You can decide if initial routing rules should still apply
    # if not lead.assigned_to: # Only run if workflow didn't assign
    #    ... your existing routing rule logic ...
    pass  # For now, we let workflows handle assignment


@csrf_exempt
def universal_lead_webhook(request):
    if request.method == 'GET':

        VERIFY_TOKEN = "your_secret_fb_token_123"
        if request.GET.get('hub.mode') == 'subscribe' and request.GET.get('hub.verify_token') == VERIFY_TOKEN:
            return HttpResponse(request.GET.get('hub.challenge'))
        return HttpResponse("Invalid verification token", status=403)

    if request.method == 'POST':
        try:
            raw_data = request.body.decode('utf-8')
            if not raw_data:
                return JsonResponse({'error': 'Empty request'}, status=400)
            webhook_data = json.loads(raw_data)
            source = detect_platform(webhook_data, request)
            lead_data = extract_lead_data(webhook_data, source)
            if not lead_data:
                return JsonResponse({'status': 'failed', 'message': 'Could not extract lead data.'}, status=400)
            email = next((lead_data.get(f) for f in ['email', 'email_address', 'work_email'] if lead_data.get(f)), None)
            if not email:
                return JsonResponse({'status': 'failed', 'message': 'Email not found.'}, status=400)
            defaults = {
                'source': source, 'raw_webhook_data': raw_data,
                'full_name': lead_data.get('full_name') or f"{lead_data.get('first_name', '')} {lead_data.get('last_name', '')}".strip(),
                'phone_number': lead_data.get('phone_number') or lead_data.get('phone'),
            }
            defaults = {k: v for k, v in defaults.items() if v}
            client, created = Client.objects.update_or_create(
                email=email.strip().lower(), defaults=defaults)
            if created:
                trigger_workflows(client)  # Use the new workflow trigger
            return JsonResponse({'status': 'success'})
        except Exception as e:
            return JsonResponse({'error': 'Internal server error'}, status=500)
    return JsonResponse({'error': 'Method not allowed'}, status=405)


# ==============================================================================
# WORKFLOW EXECUTION LOGIC (Unchanged - collapsed for brevity)
# ==============================================================================
def trigger_workflows(lead):
    active_workflows = Workflow.objects.filter(
        is_active=True, trigger_sources__contains=[lead.source])
    if not active_workflows.exists():
        return
    for workflow in active_workflows:
        execute_workflow(workflow, lead)


def execute_workflow(workflow, lead):
    steps = workflow.steps.all().order_by('order')
    for step in steps:
        action_map = {'email': action_send_email,
                      'task': action_create_task, 'assign_team': action_assign_team}
        action_function = action_map.get(step.action_type)
        if action_function:
            if not action_function(lead, step.settings_json):
                break


def action_send_email(lead, settings):
    # Your email sending logic here
    print(
        f"PRETEND: Sending email to {lead.email} with subject: '{settings.get('subject')}'")
    return True


def action_create_task(lead, settings):
    if lead.assigned_to:
        Task.objects.create(
            title=settings.get('title', 'Follow up on new lead'),
            description=settings.get('description', ''),
            client=lead,
            assigned_to=lead.assigned_to,
            due_date=timezone.now() + timedelta(days=1))
        return True
    return False


def action_assign_team(lead, settings):
    method = settings.get('assignmentMethod', 'manual')
    assignee = None
    if method == 'manual':
        team_id = settings.get('teamId')
        try:
            team = Team.objects.get(id=team_id)
            agents = User.objects.filter(
                team=team, role='agent', is_active=True)
            if agents.exists():
                assignee = agents.annotate(lead_count=Count(
                    'clients')).order_by('lead_count').first()
        except Team.DoesNotExist:
            return False
    elif method == 'automatic':
        all_active_agents = User.objects.filter(role='agent', is_active=True)
        if not all_active_agents.exists():
            return False
        assignee = all_active_agents.annotate(
            lead_count=Count('clients')).order_by('lead_count').first()
    if assignee:
        lead.assigned_to = assignee
        lead.save()
        return True
    return False

# ==============================================================================
# NEW & UPDATED WORKFLOW VIEWS
# ==============================================================================


@login_required
def workflow_chooser(request):
    """
    NEW: Displays a page for the user to select which type of workflow
    they want to create or edit.
    """
    # Define which sources can have workflows
    workflow_sources = [
        {'value': 'google_ads', 'display': 'Google Ads', 'icon': 'fab fa-google'},
        {'value': 'facebook_ads', 'display': 'Facebook Ads', 'icon': 'fab fa-facebook'},
        {'value': 'linkedin_ads', 'display': 'LinkedIn Ads', 'icon': 'fab fa-linkedin'},
        {'value': 'website_form', 'display': 'Website Form', 'icon': 'fas fa-globe'},
    ]
    return render(request, 'component/workflow_chooser.html', {'sources': workflow_sources})


@login_required
def workflow_editor(request):
    """
    UPDATED: This is the main editor view. It now checks if a workflow for the
    given source already exists and passes that information to the template.
    """
    # # Check if the source is valid
    # valid_sources = [s[0] for s in Client.SOURCE_CHOICES]
    # if source not in valid_sources:
    #     return redirect('workflow_chooser') # Or show an error

    # # Find if a workflow for this source already exists
    # existing_workflow = Workflow.objects.prefetch_related('steps').filter(trigger_sources__contains=source).first()

    # workflow_data = None
    # if existing_workflow:
    #     # Serialize the existing workflow data to pass to the frontend
    #     workflow_data = {
    #         "id": existing_workflow.id,
    #         "name": existing_workflow.name,
    #         "is_active": existing_workflow.is_active,
    #         "trigger_sources": existing_workflow.trigger_sources,
    #         "steps": [{
    #             "action_type": step.action_type,
    #             "settings": step.settings_json,
    #         } for step in existing_workflow.steps.all()]
    #     }

    # source_display_name = dict(Client.SOURCE_CHOICES).get(source, source.replace('_', ' ').title())

    # context = {
    #     'teams_json': json.dumps(list(Team.objects.values('id', 'name'))),
    #     'sources_json': json.dumps(list(Client.SOURCE_CHOICES)),
    #     'workflow_data_json': json.dumps(workflow_data), # Can be null
    #     'primary_source': source,
    #     'primary_source_name': source_display_name,
    # }
    return render(request, 'component/workflow_editor.html')


@login_required
@require_POST
@csrf_exempt
def save_workflow_api(request):
    """
    UPDATED: This API can now handle both creating new workflows and updating
    existing ones. It performs a final check for source conflicts.
    """
    try:
        data = json.loads(request.body)
        workflow_id = data.get('id')
        trigger_sources = data.get('trigger_sources', [])

        # Security check: Ensure a source isn't already used by ANOTHER workflow
        conflict_query = Workflow.objects.filter(
            trigger_sources__overlap=trigger_sources)
        if workflow_id:
            conflict_query = conflict_query.exclude(id=workflow_id)

        if conflict_query.exists():
            conflicting_wf = conflict_query.first()
            return JsonResponse({
                'status': 'error',
                'message': f"One of the sources is already used in another workflow: '{conflicting_wf.name}'"
            }, status=409)

        with transaction.atomic():
            # Use update_or_create to handle both cases
            workflow, created = Workflow.objects.update_or_create(
                id=workflow_id,
                defaults={
                    'name': data.get('name', 'Untitled Workflow'),
                    'trigger_sources': trigger_sources,
                    'is_active': data.get('is_active', True),
                    'created_by': request.user,
                }
            )

            # Delete old steps before creating new ones to ensure a clean slate
            workflow.steps.all().delete()

            # Create new steps from the submitted data
            for step_data in data.get('steps', []):
                Step.objects.create(
                    workflow=workflow,
                    order=step_data.get('order'),
                    action_type=step_data.get('action_type'),
                    settings_json=step_data.get('settings', {})
                )

        return JsonResponse({
            'status': 'success',
            'message': 'Workflow saved successfully.',
            'workflow_id': workflow.id
        })

    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


@login_required
@require_http_methods(["POST"])  # Use POST for deletion
@csrf_exempt
def delete_workflow_api(request, workflow_id):
    """
    NEW: Securely deletes a workflow by its ID.
    """
    try:
        workflow_to_delete = get_object_or_404(Workflow, id=workflow_id)
        # Optional: Add permission check to ensure request.user can delete it
        workflow_to_delete.delete()
        return JsonResponse({'status': 'success', 'message': 'Workflow deleted successfully.'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


@login_required
def workflow_list(request):
    """
    Displays a list of all created workflows, and also shows which
    sources do NOT have a workflow yet (as inactive).
    """
    # 1. सभी संभव स्रोतों की लिस्ट पाएँ
    all_possible_sources = dict(Client.SOURCE_CHOICES)

    # 2. डेटाबेस से सभी मौजूदा वर्कफ़्लोज़ निकालें
    existing_workflows = Workflow.objects.all().order_by('-created_at')

    # 3. एक डिक्शनरी बनाएँ जिसमें हर स्रोत के लिए उसका वर्कफ़्लो हो
    workflows_by_source = {
        source: wf
        for wf in existing_workflows
        for source in wf.trigger_sources
    }

    # 4. अंतिम लिस्ट बनाएँ
    display_list = []
    for source_value, source_display in all_possible_sources.items():
        if source_value in workflows_by_source:
            # अगर वर्कफ़्लो मौजूद है
            workflow = workflows_by_source[source_value]
            display_list.append({
                'name': workflow.name,
                'source_value': source_value,
                'source_display': source_display,
                'is_active': workflow.is_active,
                'created_at': workflow.created_at,
                'id': workflow.id,
                'is_dummy': False,  # यह असली वर्कफ़्लो है
            })
        else:
            # अगर वर्कफ़्लो मौजूद नहीं है
            display_list.append({
                'name': f"No workflow for {source_display}",
                'source_value': source_value,
                'source_display': source_display,
                'is_active': False,
                'created_at': None,
                'id': None,
                'is_dummy': True,  # यह एक डमी एंट्री है
            })

    context = {
        'workflows_display_list': display_list,
    }
    return render(request, 'component/workflow_list.html', context)
