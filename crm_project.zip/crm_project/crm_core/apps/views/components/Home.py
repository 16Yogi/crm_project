from django.shortcuts import render
import re


def Home(request):
    """
    Home view for the CRM application.
    This view renders the home page with basic information.
    """
    context = {}

    if request.method == 'POST':
        user_message = request.POST.get('user_message', '')
        if user_message:
            if '@' in user_message.lower():
                context['response'] = "Thanks for your email! We'll get back to you soon."
            else:
                # Extract all groups of 10 digits
                phone_matches = re.findall(r'\b\d{10}\b', user_message)
                if phone_matches:
                    context['response'] = "Thanks for providing your phone number! We'll call you soon."
                else:
                    context['response'] = "Thanks for your message!"
        else:
            context['response'] = "Please enter a message."
    
    return render(request, 'component/Home.html', context)


