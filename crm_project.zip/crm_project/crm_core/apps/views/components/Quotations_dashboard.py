from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse, HttpResponseForbidden
from django.contrib import messages
from django.utils import timezone
from django.template.loader import render_to_string
import json
from django.core.mail import send_mail


from weasyprint import HTML


from apps.models import Quotation, QuotationItem, Client, User


@login_required
def quotation_list(request):
    """
    Render the Quotations list page and handle creation of new quotations.
    """
    if request.method == 'POST':
        client_id = request.POST.get('client')
        date_issued_str = request.POST.get('date_issued')
        valid_until_str = request.POST.get('valid_until')
        items_json = request.POST.get('items_json')
        status = request.POST.get('status', 'draft')

        print("========================================================", status)

        if not all([client_id, date_issued_str, valid_until_str, items_json]):
            messages.error(request, "Please fill all required fields.")
            return redirect('quotation_list')

        try:
            client = get_object_or_404(Client, pk=client_id)
            items = json.loads(items_json)

            if not items:
                messages.error(request, "Please add at least one item.")
                return redirect('quotation_list')

            last_quote = Quotation.objects.order_by('id').last()
            new_quote_number = (last_quote.id + 1) if last_quote else 1
            quote_id_str = f"QT-{new_quote_number:04d}"

            # Create the Quotation
            quotation = Quotation.objects.create(
                quote_id=quote_id_str,
                client=client,
                created_by=request.user,
                date_issued=date_issued_str,
                valid_until=valid_until_str,
                status=status
            )

            subtotal = 0
            for item_data in items:
                quantity = int(item_data['qty'])
                unit_price = float(item_data['price'])
                total = quantity * unit_price
                subtotal += total

                QuotationItem.objects.create(
                    quotation=quotation,
                    description=item_data['desc'],
                    quantity=quantity,
                    unit_price=unit_price,
                    total=total
                )

            quotation.subtotal = subtotal
            tax_amount = subtotal * (float(quotation.tax_percentage) / 100)
            quotation.tax_amount = tax_amount
            quotation.total_amount = subtotal + tax_amount
            quotation.save()

            # If status is 'send', send email to client
            if status == 'sent':
                subject = f"Quotation {quotation.quote_id} from {request.user}"
                message = f"""
                Dear 'ritikparte93@gmail.com',
 
                Please find your quotation {quotation.quote_id}.

                Date Issued: {quotation.date_issued}
                Valid Until: {quotation.valid_until}
                Subtotal: {quotation.subtotal}
                Tax: {quotation.tax_amount}
                Total Amount: {quotation.total_amount}

                Thank you for your business.
                """
                recipient_list = ['ritikparte93@gmail.com']

                send_mail(
                    subject=subject,
                    message=message,
                    from_email=None,  # Uses DEFAULT_FROM_EMAIL
                    recipient_list=recipient_list,
                    fail_silently=False,
                )

                messages.success(
                    request, f"Quotation {quotation.quote_id} created and sent to {client.email}!")
            else:
                messages.success(
                    request, f"Quotation {quotation.quote_id} created successfully!")

            return redirect('quotation_list')

        except Exception as e:
            messages.error(request, f"An error occurred: {e}")
            return redirect('quotation_list')
        

    quotations = Quotation.objects.select_related('client').all().order_by('-created_at')
    
    # Get filter parameters from the URL (request.GET)
    client_name = request.GET.get('client_name', '')
    status_filter = request.GET.get('status', '')
    date_from = request.GET.get('date_from', '')
    date_to = request.GET.get('date_to', '')

    # Apply filters to the queryset if they exist
    if client_name:
        quotations = quotations.filter(client__full_name__icontains=client_name)
    
    if status_filter:
        quotations = quotations.filter(status=status_filter)
        
    if date_from:
        quotations = quotations.filter(date_issued__gte=date_from)
        
    if date_to:
        quotations = quotations.filter(date_issued__lte=date_to)

    clients = Client.objects.all()


    context = {
        'title': 'Quotations',
        'quotations': quotations,
        'clients': clients,
        'status_choices': Quotation.STATUS_CHOICES,
        'current_filters': request.GET 
    }
    return render(request, 'component/Quotations_dashboard.html', context)


@login_required
def quotation_edit(request, quote_id):
    """
    Handle editing of an existing quotation.
    """
    quotation = get_object_or_404(Quotation, pk=quote_id)

    if request.method == 'POST':
        client_id = request.POST.get('client')
        date_issued_str = request.POST.get('date_issued')
        valid_until_str = request.POST.get('valid_until')
        items_json = request.POST.get('items_json')
        status = request.POST.get('status', 'draft')

        try:
            quotation.client = get_object_or_404(Client, pk=client_id)
            quotation.date_issued = date_issued_str
            quotation.valid_until = valid_until_str
            quotation.status = status

            quotation.items.all().delete()

            items = json.loads(items_json)
            subtotal = 0
            for item_data in items:
                quantity = int(item_data['qty'])
                unit_price = float(item_data['price'])
                total = quantity * unit_price
                subtotal += total
                QuotationItem.objects.create(
                    quotation=quotation, description=item_data['desc'],
                    quantity=quantity, unit_price=unit_price, total=total)

            quotation.subtotal = subtotal
            tax_amount = subtotal * (float(quotation.tax_percentage) / 100)
            quotation.tax_amount = tax_amount
            quotation.total_amount = subtotal + tax_amount
            quotation.save()

            messages.success(
                request, f"Quotation {quotation.quote_id} updated successfully!")
            return redirect('quotation_list')
        except Exception as e:
            messages.error(request, f"An error occurred during update: {e}")

    return redirect('quotation_list')


@login_required
def quotation_download_pdf(request, quote_id):
    """
    Generate and download a PDF for a specific quotation.
    """
    quotation = get_object_or_404(Quotation.objects.select_related(
        'client').prefetch_related('items'), pk=quote_id)

    context = {'quotation': quotation}
    html_string = render_to_string(
        'component/quotation_pdf_template.html', context)

    html = HTML(string=html_string, base_url=request.build_absolute_uri())
    pdf = html.write_pdf()

    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="Quotation-{quotation.quote_id}.pdf"'

    return response
