from  django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required



@login_required
def agent(request):
    """
    Render the agent dashboard.
    """
    context = {
        'user': request.user, 
    }
    
    return render(request, 'component/Dashboard_agent.html', context)