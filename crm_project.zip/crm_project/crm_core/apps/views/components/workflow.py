

from django.shortcuts import render
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
import json
from apps.models import Workflow, WebsiteSetting, Client 

@login_required
def workflow_list(request):
    """
    Displays a list of all created workflows.
    """
    workflows = Workflow.objects.all().order_by('-created_at')
    website_setting = WebsiteSetting.load()
    

    source_choices = Client.SOURCE_CHOICES

    for workflow in workflows:
        workflow.formatted_sources = [source.replace('_', ' ').title() for source in workflow.trigger_sources]
    
    context = {
        'workflows': workflows,
        'website_setting': website_setting,
        'source_choices': source_choices,
    }
    
    return render(request, 'component/workflow.html', context)



@login_required
@csrf_exempt 
@require_POST
def save_workflow_api(request):
    """
    Creates a new workflow or updates an existing one.
    """
    try:
        data = json.loads(request.body)
        workflow_id = data.get('workflow_id')
        
        # 'is_active' checkbox se 'on' ya None aata hai, use boolean mein convert karein
        is_active = data.get('is_active') == 'on'
        
        defaults = {
            'name': data.get('name'),
            'is_active': is_active,
            'trigger_sources': data.get('trigger_sources', []), # Yeh ek list honi chahiye
        }

        if workflow_id:
            workflow, created = Workflow.objects.update_or_create(id=workflow_id, defaults=defaults)
            message = "Workflow updated successfully."
        else:
        
            defaults['created_by'] = request.user
            workflow = Workflow.objects.create(**defaults)
            message = "Workflow created successfully."
            
        return JsonResponse({'status': 'success', 'message': message})

    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=400)


@login_required
@csrf_exempt
@require_POST
def delete_workflow_api(request):
    """
    Deletes a workflow.
    """
    try:
        data = json.loads(request.body)
        workflow_id = data.get('workflow_id')
        
        workflow = Workflow.objects.get(id=workflow_id)
        workflow.delete()
        
        return JsonResponse({'status': 'success', 'message': 'Workflow deleted successfully.'})

    except Workflow.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Workflow not found.'}, status=404)
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=400)