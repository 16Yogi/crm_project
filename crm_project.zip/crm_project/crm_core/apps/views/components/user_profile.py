from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash, logout
from django.contrib.auth.forms import PasswordChangeForm
from apps.models import User # Make sure to import your User model


@login_required
def user_profile(request, user_id=None):
    """
    Handles displaying and updating user profiles.
    - If user_id is None, it shows the logged-in user's own profile.
    - If user_id is provided, it allows an admin/supervisor to view/edit another user's profile.
    """
    
    viewing_user = request.user
    
    if user_id:
        # Scenario: Viewing/editing another user's profile.
        profile_user = get_object_or_404(User, id=user_id)
        if not viewing_user.role == 'admin' and viewing_user.id != profile_user.id:
            messages.error(request, "You do not have permission to view this profile.")
            # Redirect to a safe page like your own profile or dashboard
            return redirect('my_profile') 
    else:
        # Scenario: Viewing/editing your own profile.
        profile_user = viewing_user

    # Determine if the current user has permission to edit the profile being viewed.
    can_edit = (viewing_user.role == 'admin') or (viewing_user.id == profile_user.id)

    if request.method == 'POST':
        # Double-check permission before processing the form.
        if not can_edit:
            messages.error(request, "You do not have permission to perform this action.")
            # Redirect safely.
            if user_id:
                return redirect('user_profile', user_id=user_id)
            else:
                return redirect('my_profile')
        
        action = request.POST.get('action')

        if action == 'update_profile':
            profile_user.first_name = request.POST.get('first_name', '')
            profile_user.last_name = request.POST.get('last_name', '')
            profile_user.email = request.POST.get('email', '')

            if request.FILES.get('profile_picture'):
                profile_user.profile_picture = request.FILES['profile_picture']

            if viewing_user.role == 'admin' and 'role' in request.POST:
                 profile_user.role = request.POST.get('role')
            
            profile_user.save()
            messages.success(request, f"Profile for {profile_user.get_full_name()} has been updated successfully.")
        
        elif action == 'change_password':
            if viewing_user.id != profile_user.id:
                 messages.error(request, "You cannot change another user's password directly.")
            else:
                form = PasswordChangeForm(profile_user, request.POST)
                if form.is_valid():
                    user = form.save()
                    update_session_auth_hash(request, user) # Keep the user logged in
                    messages.success(request, 'Your password was successfully updated!')
                else:
                    # Display form errors to the user
                    for field, error_list in form.errors.items():
                        for error in error_list:
                            messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
        
        # --- THIS IS THE CORRECTED REDIRECT LOGIC ---
        # After processing the form, we redirect the user to the correct page.
        if user_id:
            # If we were editing another user, redirect back to their profile page.
            return redirect('user_profile', user_id=user_id)
        else:
            # If we were editing our own profile, redirect back to our profile page.
            return redirect('my_profile')
    
    # This context is for GET requests (when the page first loads).
    context = {
        'profile_user': profile_user,
        'can_edit': can_edit,
        'role_choices': User.ROLE_CHOICES,
    }
    return render(request, 'component/user_profile.html', context)


@login_required
def user_profile_logout(request):
    """
    Handles logging out the user via a GET request from a link.
    """
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect('login_page')