from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required


@login_required
def integration_dashboard(request):
    if request.method == 'POST':
        integration_type = request.POST.get('integration_type')
        if integration_type:

            return redirect('integration_dashboard')
    return render(request, 'component/integration_dashboard.html', {
        'title': 'Integration Dashboard',
        'active_tab': 'integrations'
    })