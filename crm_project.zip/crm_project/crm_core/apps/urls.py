# apps/urls.py

from django.urls import path
from apps.views.components.Dashboard_admin import *
from apps.views.components.LoginScreen import *
from apps.views.components.Usermangement import *
from apps.views.components.Dashboard_Agent import *
from apps.views.components.NewCampaign import *
from apps.views.components.Home import *
from apps.views.components.Leadmangement import *
from apps.views.components.Setting import *
from apps.views.components.integration_dashboard import *
from apps.views.components.Quotations_dashboard import *
from apps.views.components.Team_perfomance import *
from apps.views.components.user_profile import *
from apps.views.components.workflow import *

urlpatterns = [
    # General & Authentication
    path('', Home, name='home'),
    path('login/', LoginScreen, name='login_page'),
    path('logout/', user_profile_logout, name='logout'),  

    # Dashboards
    path('admin_dashboard/', admin, name='admin_dashboard'),
    path('agent_dashboard/', agent, name='agent_dashboard'),

    # User & Team Management
    path('user_management/', user_management, name='user_management'),
    path('users/<int:user_id>/activate/', activate_user, name='activate_user'),
    path('users/<int:user_id>/deactivate/', deactivate_user, name='deactivate_user'),
    path('users/<int:user_id>/delete/', delete_user, name='delete_user'),
    path('Team_perfomance/', team_performance, name='Team_perfomance'),

    # --- CORRECTED USER PROFILE URLS ---
    # For viewing/editing your OWN profile (e.g., /profile/)
    path('profile/', user_profile, name='my_profile'),
    # For viewing/editing ANOTHER user's profile (e.g., /profile/123/)
    path('profile/<int:user_id>/', user_profile, name='user_profile'),
    # REMOVED: path('user_profile/', user_profile, name='user_profile'), # This was the conflicting line

    # Leads & Webhooks
    path('lead_management/', lead_management, name='lead_management'),
    path('webhooks/leads/', universal_lead_webhook, name='universal_lead_webhook'),

    # Workflows & Rules
    path('workflows/', workflow_list, name='workflow_list'),
    path('api/rules/save/', rule_create_or_update_api, name='rule_save_api'),
    path('api/rules/delete/', rule_delete_api, name='rule_delete_api'),

    # Quotations
    path('quotations/', quotation_list, name='quotation_list'),
    path('quotations/<int:quote_id>/edit/', quotation_edit, name='quotation_edit'),
    path('quotations/download/<int:quote_id>/', quotation_download_pdf, name='quotation_download_pdf'),
    
    # Settings & Integrations
    path('settings/', Setting, name='settings'),
    path('integrations/', integration_dashboard, name='integrations'),

    path('api/workflows/save/', save_workflow_api, name='save_workflow_api'),
    path('api/workflows/delete/', delete_workflow_api, name='delete_workflow_api'),
]