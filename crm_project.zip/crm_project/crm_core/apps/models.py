from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractUser
import json 



# Teams models
class Team(models.Model):
    name = models.CharField(max_length=100, unique=True)
    supervisor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        limit_choices_to={'role': 'supervisor'},
        related_name='supervised_teams',
        help_text="Supervisor of the team."
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

# --- 1. User Model ---
class User(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('supervisor', 'Supervisor'),
        ('agent', 'Agent'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='agent')

    profile_picture = models.ImageField(
        upload_to='profile_pictures/',
        null=True,
        blank=True,
        help_text="Profile picture of the user.",
        default='profile_pictures/default.png'
    )
    team = models.ForeignKey(
        Team,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='members',
        help_text="Team this user belongs to.",
    )

    reports_to = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='direct_reports',
        limit_choices_to={'role': 'supervisor'},
        help_text="The supervisor this user reports to."
    )

    def __str__(self):
        return self.get_full_name() or self.username

class Client(models.Model):
    SOURCE_CHOICES = [
        ('google_ads', 'Google Ads'),
        ('facebook_ads', 'Facebook Ads'),
        ('linkedin_ads', 'LinkedIn Ads'),
        ('website_form', 'Website Form'),
        ('manual_entry', 'Manual Entry'),
        ('referral', 'Referral'),
        ('other', 'Other'),
    ]
    STATUS_CHOICES = [
        ('new', 'New Lead'),
        ('contacted', 'Contacted'),
        ('qualified', 'Qualified'),
        ('proposal_sent', 'Proposal Sent'),
        ('customer', 'Customer'),
        ('lost', 'Lost'),
    ]

    full_name = models.CharField(max_length=255)
    email = models.EmailField(unique=True, help_text="Primary contact email.")
    phone_number = models.CharField(max_length=20, null=True, blank=True)
    company_name = models.CharField(max_length=200, null=True, blank=True)
    job_title = models.CharField(max_length=150, null=True, blank=True)
    country = models.CharField(max_length=100, null=True, blank=True)
    city = models.CharField(max_length=100, null=True, blank=True)

    source = models.CharField(
        max_length=50,
        choices=SOURCE_CHOICES,
        default='manual_entry',
        help_text="The platform where this client was acquired from."
    )
    status = models.CharField(
        max_length=50,
        choices=STATUS_CHOICES,
        default='new',
        help_text="Current status of the client in the sales funnel."
    )

    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='clients',
        help_text="User assigned to manage this client."
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    raw_webhook_data = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.full_name

    class Meta:
        verbose_name = 'Client / Lead'
        verbose_name_plural = 'Clients & Leads'
        ordering = ['-created_at']

# --- 3. Deal Model ---
class Deal(models.Model):
    STAGE_CHOICES = [
        ('prospecting', 'Prospecting'),
        ('qualification', 'Qualification'),
        ('proposal', 'Proposal Sent'),
        ('negotiation', 'Negotiation'),
        ('won', 'Won'),
        ('lost', 'Lost'),
    ]

    title = models.CharField(max_length=255)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='deals')
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='deals'
    )
    value = models.DecimalField(max_digits=10, decimal_places=2, help_text="The potential or actual value of the deal.")
    stage = models.CharField(max_length=50, choices=STAGE_CHOICES, default='prospecting')
    expected_close_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.title} - {self.client.full_name}"

# --- 4. Task Model ---
class Task(models.Model):
    PRIORITY_CHOICES = [('low', 'Low'), ('medium', 'Medium'), ('high', 'High')]

    title = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='tasks'
    )
    client = models.ForeignKey(Client, on_delete=models.SET_NULL, null=True, blank=True, related_name='tasks')
    deal = models.ForeignKey(Deal, on_delete=models.SET_NULL, null=True, blank=True, related_name='tasks')
    due_date = models.DateTimeField()
    is_completed = models.BooleanField(default=False)
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='medium')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

    class Meta:
        ordering = ['due_date']


# --- WORKFLOW MODEL ---
class Workflow(models.Model):
    name = models.CharField(max_length=255)
    trigger_sources = models.JSONField(default=list, blank=True, help_text="List of source types that trigger this workflow")
    is_active = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_workflows'
    )

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['-created_at']


# --- STEP MODEL ---
class Step(models.Model):
    ACTION_CHOICES = [
        ('email', 'Send Email'),
        ('sms', 'Send SMS'),
        ('task', 'Create Task'),
        ('assign_team', 'Assign to Team'),
        ('wait', 'Wait / Delay'),
        ('check_condition', 'Check Condition'),
    ]

    workflow = models.ForeignKey(Workflow, on_delete=models.CASCADE, related_name='steps')
    order = models.PositiveIntegerField()
    action_type = models.CharField(max_length=50, choices=ACTION_CHOICES)

    # This will store all the configuration for each step type
    settings_json = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ['order']
        # Ensure unique step order within each workflow
        unique_together = ['workflow', 'order']

    def __str__(self):
        return f"Step {self.order}: {self.get_action_type_display()}"


# Other models (RoutingRule, Quotation, etc.) remain unchanged
class RoutingRule(models.Model):
    name = models.CharField(max_length=255)
    priority = models.PositiveIntegerField(default=10, help_text="Lower numbers indicate higher priority")
    condition_field = models.CharField(max_length=100, help_text="e.g., 'campaign_name', 'source', etc.")
    condition_operator = models.CharField(max_length=20, choices=[('contains', 'Contains'), ('equals', 'Equals')])
    condition_value = models.CharField(max_length=255)
    target_team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='routing_rules')

    class Meta:
        ordering = ['priority']

    def __str__(self):
        return f"{self.priority}: {self.name}"


class Quotation(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('sent', 'Sent'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
    ]

    quote_id = models.CharField(max_length=50, unique=True, help_text="e.g., QT-0001")
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='quotations')
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    date_issued = models.DateField()
    valid_until = models.DateField()

    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    tax_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=10.00, help_text="Tax rate in percentage")
    tax_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.quote_id} for {self.client.full_name}"
    
    @property
    def items_json(self):
        """
        Returns a JSON string of all items with keys that match the JavaScript code.
        """
        items_list = []
        # 'items' related_name se aa raha hai
        for item in self.items.all(): 
            items_list.append({
                'description': item.description,
                'quantity': item.quantity,
                'unit_price': f"{item.unit_price:.2f}" # Convert Decimal to string
            })
        return json.dumps(items_list)

    class Meta:
        ordering = ['-date_issued']


class QuotationItem(models.Model):
    # 'related_name="items"' yahan bahut zaroori hai taaki upar property kaam kare
    quotation = models.ForeignKey(Quotation, on_delete=models.CASCADE, related_name='items') 
    description = models.CharField(max_length=255, help_text="Name of the service or product")
    quantity = models.PositiveIntegerField(default=1)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    total = models.DecimalField(max_digits=12, decimal_places=2)

    def save(self, *args, **kwargs):
        self.total = self.quantity * self.unit_price
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.description} (x{self.quantity}) for {self.quotation.quote_id}"
    



class WebsiteSetting(models.Model):
    """
    Ek singleton model sirf website ka naam store karne ke liye.
    """
    website_name = models.CharField(max_length=100, default='CRM Pro')

    def __str__(self):
        return self.website_name

    def save(self, *args, **kwargs):
        # Yeh ensure karega ki hamesha ek hi entry (ID=1) rahe.
        self.pk = 1
        super(WebsiteSetting, self).save(*args, **kwargs)

    @classmethod
    def load(cls):
        # Yeh helper function uss ek entry ko laayega ya create karega.
        obj, created = cls.objects.get_or_create(pk=1)
        return obj